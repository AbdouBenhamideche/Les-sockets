﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationDuVin
{
    internal class Echantillon
    {
        public float alcohol {  get; set; }
        public float sulphates {  get; set; }
        public float criticAcid {  get; set; }
        public int quality { get; set; }
    }
}
