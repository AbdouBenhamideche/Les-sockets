﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationDuVin
{
    public class Node
    {
        public string Attribute { get; set; }
        public Dictionary<string, Node> Children { get; set; }
        public int Class { get; set; }
        public double? SplitValue { get; set; }



        public static double DiscretizeNumericAttribute(List<Vin> data, int attributeIndex)
        {
            // Sort the data by the selected numeric attribute
            data.Sort((a, b) => a.GetAttributeValue(attributeIndex).CompareTo(b.GetAttributeValue(attributeIndex)));

            double lowerBound = data.First().GetAttributeValue(attributeIndex);
            double upperBound = data.Last().GetAttributeValue(attributeIndex);

            // Calculate the mean between the bounds
            double discretizationSplitValue = (lowerBound + upperBound) / 2.0;

            return discretizationSplitValue;
        }

    }
}
 
